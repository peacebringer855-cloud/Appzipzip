// Root build configuration for the calculator project

groups = listOf("calculator")

plugins {
    id("com.android.application") version "8.2.0"
    id("org.jetbrains.kotlin.android") version "1.9.0"
    id("kotlin-kapt") version "1.9.0"
    id("kotlin-parcelize") version "1.9.0"
}

allprojects {
    repositories {
        google()
        mavenCentral()
        maven { url = uri("https://jitpack.io") }
    }
}

customize {
    kotlinCompilerExposingInternalKotlinApi()
}

val composeCompilerVersion = "1.5.3"

val androidVersions = object {
    const val minSdk = 24
    const val targetSdk = 34
    const val compileSdk = 34
}