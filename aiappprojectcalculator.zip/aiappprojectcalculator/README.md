# AI Project Calculator App

A simple and intuitive calculator application built with modern Android development practices.

## Features

- Basic arithmetic operations (+, -, *, /)
- Clear and reset functionality
- Display history
- Responsive UI
- Material Design 3 components

## Tech Stack

- Android SDK
- Jetpack Compose
- Kotlin
- MVVM Architecture
- Coroutines
- Flow

## Project Structure

```
aiappprojectcalculator/
├── app/
│   ├── src/
│   │   ├── main/
│   │   │   ├── java/com/example/calculator/
│   │   │   ├── res/
│   │   │   └── AndroidManifest.xml
│   │   └── test/
│   └── build.gradle.kts
├── build.gradle.kts
└── gradle.properties
```

## Building the App

1. Open in Android Studio
2. Sync Gradle files
3. Click Run button

## Screenshots

[Add screenshots here]

## License

This project is open source and available under the MIT License.