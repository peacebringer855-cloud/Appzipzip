package com.example.calculator

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Clear
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            CalculatorApp()
        }
    }
}

@Composable
fun CalculatorApp() {
    var displayText by remember { mutableStateOf("0") }
    var historyText by remember { mutableStateOf("") }
    var isResult by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1E1E1E)),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Bottom
    ) {
        // History Display
        Text(
            text = historyText,
            color = Color.Gray,
            fontSize = 20.sp,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            textAlign = TextAlign.Right
        )

        // Main Display
        Text(
            text = displayText,
            color = Color.White,
            fontSize = if (displayText.length > 10) 28.sp else 48.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            textAlign = TextAlign.Right
        )

        // Calculator Buttons
        val buttons = listOf(
            listOf("C", "±", "%", "÷"),
            listOf("7", "8", "9", "×"),
            listOf("4", "5", "6", "-"),
            listOf("1", "2", "3", "+"),
            listOf("0", ".", "=")
        )

        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            buttons.forEach { rowButtons ->
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(70.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    rowButtons.forEach { buttonText ->
                        CalculatorButton(
                            text = buttonText,
                            onClick = {
                                when (buttonText) {
                                    "C" -> {
                                        displayText = "0"
                                        isResult = false
                                    }
                                    "±" -> {
                                        if (displayText != "0") {
                                            val value = displayText.toDoubleOrNull() ?: 0.0
                                            displayText = if (value >= 0) "-$value" else "${-value}"
                                        }
                                    }
                                    "%" -> {
                                        if (displayText != "0") {
                                            val value = displayText.toDoubleOrNull() ?: 0.0
                                            displayText = "${value / 100}"
                                        }
                                    }
                                    "÷" -> {
                                        if (!isResult) {
                                            displayText += " / "
                                            isResult = false
                                        }
                                    }
                                    "×" -> {
                                        if (!isResult) {
                                            displayText += " * "
                                            isResult = false
                                        }
                                    }
                                    "-" -> {
                                        if (!isResult) {
                                            displayText += " - "
                                            isResult = false
                                        }
                                    }
                                    "+" -> {
                                        if (!isResult) {
                                            displayText += " + "
                                            isResult = false
                                        }
                                    }
                                    "=" -> {
                                        try {
                                            val expression = displayText.replace("×", "*").replace("÷", "/")
                                            val result = evaluateExpression(expression)
                                            historyText = displayText + " = " + result
                                            displayText = result.toString()
                                            isResult = true
                                        } catch (e: Exception) {
                                            displayText = "Error"
                                        }
                                    }
                                    else -> {
                                        if (displayText == "0" || isResult) {
                                            displayText = buttonText
                                            isResult = false
                                        } else {
                                            displayText += buttonText
                                        }
                                    }
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(12.dp))
            }
        }

        // Clear Button at bottom
        Button(
            onClick = {
                displayText = "0"
                historyText = ""
                isResult = false
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .height(56.dp),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFF2D2D2D),
                contentColor = Color.White
            )
        ) {
            Icon(Icons.Default.Clear, contentDescription = "Clear All")
            Spacer(modifier = Modifier.weight(1f))
            Text("AC")
        }
    }
}

@Composable
fun CalculatorButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val buttonColor = when {
        text in listOf("C", "±", "%") -> Color(0xFF3A3A3A)
        text in listOf("÷", "×", "-", "+") -> Color(0xFF6B46C1)
        text == "=" -> Color(0xFF6B46C1)
        else -> Color(0xFF2D2D2D)
    }

    val textColor = when {
        text in listOf("÷", "×", "-", "+", "=") -> Color.White
        else -> Color.White
    }

    Button(
        onClick = onClick,
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = ButtonDefaults.buttonColors(
            containerColor = buttonColor,
            contentColor = textColor
        )
    ) {
        Text(
            text = text,
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

fun evaluateExpression(expression: String): Double {
    val sanitized = expression.replace("×", "*").replace("÷", "/")
    return try {
        val result = evaluate(sanitized)
        if (result.isFinite()) {
            result
        } else {
            throw Exception("Invalid calculation")
        }
    } catch (e: Exception) {
        throw e
    }
}

fun evaluate(expr: String): Double {
    return object : Any() {
        private var pos = 0
        private var currentNumber = 0.0
        private var lastOperator = '+'
        private var result = 0.0

        fun parse(): Double {
            while (pos < expr.length) {
                when {
                    expr[pos].isDigit() || expr[pos] == '.' -> {
                        val number = parseNumber()
                        applyOperator(lastOperator, number)
                    }
                    expr[pos] in listOf('+', '-', '*', '/') -> {
                        lastOperator = expr[pos]
                        pos++
                    }
                    expr[pos] == '(' -> {
                        pos++
                        val parenthesesResult = parse()
                        applyOperator(lastOperator, parenthesesResult)
                    }
                    expr[pos] == ')' -> {
                        pos++
                        return result
                    }
                    else -> pos++
                }
            }
            return result
        }

        private fun parseNumber(): Double {
            val start = pos
            while (pos < expr.length && (expr[pos].isDigit() || expr[pos] == '.')) {
                pos++
            }
            return expr.substring(start, pos).toDouble()
        }

        private fun applyOperator(operator: Char, number: Double) {
            when (operator) {
                '+' -> result += number
                '-' -> result -= number
                '*' -> result *= number
                '/' -> {
                    if (number != 0.0) {
                        result /= number
                    } else {
                        throw Exception("Division by zero")
                    }
                }
            }
        }

        init {
            parse()
        }

        override fun toString(): String = result.toString()
    }.result
}